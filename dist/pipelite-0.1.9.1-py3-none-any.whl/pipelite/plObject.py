__author__ = "datacorner.fr"
__email__ = "admin@datacorner.fr"
__license__ = "MIT"

class plObject:
    def __init__(self, __config, __log):
        self.log = __log
        self.config = __config    