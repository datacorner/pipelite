__author__ = "datacorner.fr"
__email__ = "admin@datacorner.fr"
__license__ = "MIT"

from pipelite import main

# main call
if __name__ == "__main__":
	main()